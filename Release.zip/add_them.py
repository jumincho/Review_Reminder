import sys
from todoist.api import TodoistAPI
args=sys.argv[1:]
api = TodoistAPI(args[0])
api.sync()

if args[1] == 'sync':
    temp = api.state["items"][3:]
    for number in range(len(temp)):
        print(temp[number].data["content"])
        print(temp[number].data["date_added"])
        print(temp[number].data["checked"])
        print(temp[number].data["id"])
       
if args[1] == 'delete':
    item = api.items.get_by_id(int(args[2]))
    item.delete()
    api.commit()

if args[1] == 'add':
    temp = "";
    for number in range(len(args)-2):
        temp = temp +" "+ args[number+2]
    item = api.items.add(temp)
    api.commit()

